export const environment = {
  production: true,
  apiServer: 'http://auction.sharkdev.eu/api/api/',
  imagePath: 'http://auction.sharkdev.eu/api/images/',
  titlePrefix: 'Online Auction'
};
